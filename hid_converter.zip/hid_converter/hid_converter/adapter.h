#ifndef ADAPTER_H
#define ADAPTER_H

#include <windows.h>
#include <setupapi.h>
#include <hidsdi.h>

// Function pointer typedefs
typedef void (__stdcall *HidD_GetHidGuid_t)(LPGUID HidGuid);
typedef BOOLEAN (__stdcall *HidD_GetAttributes_t)(HANDLE HidDeviceObject, PHIDD_ATTRIBUTES Attributes);
typedef BOOLEAN (__stdcall *HidD_SetOutputReport_t)(HANDLE HidDeviceObject, PVOID ReportBuffer, ULONG ReportBufferLength);
typedef BOOLEAN (__stdcall *HidD_GetInputReport_t)(HANDLE HidDeviceObject, PVOID ReportBuffer, ULONG ReportBufferLength);
typedef BOOLEAN (__stdcall *HidD_SetFeature_t)(HANDLE HidDeviceObject, PVOID ReportBuffer, ULONG ReportBufferLength);
typedef BOOLEAN (__stdcall *HidD_GetFeature_t)(HANDLE HidDeviceObject, PVOID ReportBuffer, ULONG ReportBufferLength);

// SetupAPI typedefs
typedef HDEVINFO (__stdcall *SetupDiGetClassDevsA_t)(const GUID *ClassGuid, PCSTR Enumerator, HWND hwndParent, DWORD Flags);
typedef BOOL (__stdcall *SetupDiEnumDeviceInterfaces_t)(HDEVINFO DeviceInfoSet, PSP_DEVINFO_DATA DeviceInfoData, const GUID *InterfaceClassGuid, DWORD MemberIndex, PSP_DEVICE_INTERFACE_DATA DeviceInterfaceData);
typedef BOOL (__stdcall *SetupDiGetDeviceInterfaceDetailA_t)(HDEVINFO DeviceInfoSet, PSP_DEVICE_INTERFACE_DATA DeviceInterfaceData, PSP_DEVICE_INTERFACE_DETAIL_DATA_A DeviceInterfaceDetailData, DWORD DeviceInterfaceDetailDataSize, PDWORD RequiredSize, PSP_DEVINFO_DATA DeviceInfoData);
typedef BOOL (__stdcall *SetupDiDestroyDeviceInfoList_t)(HDEVINFO DeviceInfoSet);

// Extern pointers with X suffix
extern HidD_GetHidGuid_t HidD_GetHidGuidX;
extern HidD_GetAttributes_t HidD_GetAttributesX;
extern HidD_SetOutputReport_t HidD_SetOutputReportX;
extern HidD_GetInputReport_t HidD_GetInputReportX;
extern HidD_SetFeature_t HidD_SetFeatureX;
extern HidD_GetFeature_t HidD_GetFeatureX;

extern SetupDiGetClassDevsA_t SetupDiGetClassDevsAX;
extern SetupDiEnumDeviceInterfaces_t SetupDiEnumDeviceInterfacesX;
extern SetupDiGetDeviceInterfaceDetailA_t SetupDiGetDeviceInterfaceDetailAX;
extern SetupDiDestroyDeviceInfoList_t SetupDiDestroyDeviceInfoListX;

// ✅ New helper function
HANDLE OpenHidDevice(WORD vid, WORD pid);

void   CloseHidDevice(HANDLE hDevice);

// Init / free functions
int InitAdapterFunctions(void);
void FreeAdapterFunctions(void);

// --- CP2112 helper functions ---
int CP2112_GetPartNumber(HANDLE hDevice, BYTE *partNumber);
int CP2112_GetVersion(HANDLE hDevice, WORD *version);

#endif // ADAPTER_H
