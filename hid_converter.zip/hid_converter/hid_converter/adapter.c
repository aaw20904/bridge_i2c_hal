#include "adapter.h"
#include <stdio.h>

#include <string.h>
// CP2112 Feature Report IDs (from datasheet) only for debug
#define CP2112_GET_PART_NUMBER   0xFF
#define CP2112_GET_VERSION       0xF1

HINSTANCE hHidDll = NULL;
HINSTANCE hSetupApiDll = NULL;

HANDLE hSerial;

// Define all pointers
HidD_GetHidGuid_t HidD_GetHidGuidX = NULL;
HidD_GetAttributes_t HidD_GetAttributesX = NULL;
HidD_SetOutputReport_t HidD_SetOutputReportX = NULL;
HidD_GetInputReport_t HidD_GetInputReportX = NULL;
HidD_SetFeature_t HidD_SetFeatureX = NULL;
HidD_GetFeature_t HidD_GetFeatureX = NULL;

SetupDiGetClassDevsA_t SetupDiGetClassDevsAX = NULL;
SetupDiEnumDeviceInterfaces_t SetupDiEnumDeviceInterfacesX = NULL;
SetupDiGetDeviceInterfaceDetailA_t SetupDiGetDeviceInterfaceDetailAX = NULL;
SetupDiDestroyDeviceInfoList_t SetupDiDestroyDeviceInfoListX = NULL;

int InitAdapterFunctions(void)
{
    hHidDll = LoadLibraryA("hid.dll");
    hSetupApiDll = LoadLibraryA("setupapi.dll");

    if (!hHidDll || !hSetupApiDll) {
        printf("Failed to load DLLs\n");
        return -1;
    }

    // HID functions
    HidD_GetHidGuidX = (HidD_GetHidGuid_t)GetProcAddress(hHidDll, "HidD_GetHidGuid");
    HidD_GetAttributesX = (HidD_GetAttributes_t)GetProcAddress(hHidDll, "HidD_GetAttributes");
    HidD_SetOutputReportX = (HidD_SetOutputReport_t)GetProcAddress(hHidDll, "HidD_SetOutputReport");
    HidD_GetInputReportX = (HidD_GetInputReport_t)GetProcAddress(hHidDll, "HidD_GetInputReport");
    HidD_SetFeatureX = (HidD_SetFeature_t)GetProcAddress(hHidDll, "HidD_SetFeature");
    HidD_GetFeatureX = (HidD_GetFeature_t)GetProcAddress(hHidDll, "HidD_GetFeature");

    // SetupAPI functions
    SetupDiGetClassDevsAX = (SetupDiGetClassDevsA_t)GetProcAddress(hSetupApiDll, "SetupDiGetClassDevsA");
    SetupDiEnumDeviceInterfacesX = (SetupDiEnumDeviceInterfaces_t)GetProcAddress(hSetupApiDll, "SetupDiEnumDeviceInterfaces");
    SetupDiGetDeviceInterfaceDetailAX = (SetupDiGetDeviceInterfaceDetailA_t)GetProcAddress(hSetupApiDll, "SetupDiGetDeviceInterfaceDetailA");
    SetupDiDestroyDeviceInfoListX = (SetupDiDestroyDeviceInfoList_t)GetProcAddress(hSetupApiDll, "SetupDiDestroyDeviceInfoList");

    if (!HidD_GetHidGuidX || !HidD_GetAttributesX || !HidD_SetFeatureX || !HidD_GetFeatureX) {
        printf("Failed to load one or more HID functions\n");
        return -2;
    }
    if (!SetupDiGetClassDevsAX || !SetupDiEnumDeviceInterfacesX || !SetupDiGetDeviceInterfaceDetailAX || !SetupDiDestroyDeviceInfoListX) {
        printf("Failed to load one or more SetupAPI functions\n");
        return -3;
    }

    return 0;
}





// ✅ Helper to open HID device by VID/PID
HANDLE OpenHidDevice(WORD vid, WORD pid) {
    GUID hidGuid;
    HidD_GetHidGuidX(&hidGuid);

    HDEVINFO hDevInfo = SetupDiGetClassDevsAX(&hidGuid, NULL, NULL,
                                              DIGCF_PRESENT | DIGCF_DEVICEINTERFACE);
    if (hDevInfo == INVALID_HANDLE_VALUE) {
        return INVALID_HANDLE_VALUE;
    }

    SP_DEVICE_INTERFACE_DATA devInterfaceData;
    devInterfaceData.cbSize = sizeof(SP_DEVICE_INTERFACE_DATA);

    HANDLE hDevice = INVALID_HANDLE_VALUE;

    for (DWORD i = 0; SetupDiEnumDeviceInterfacesX(hDevInfo, NULL, &hidGuid, i, &devInterfaceData); i++) {
        DWORD requiredSize = 0;
        SetupDiGetDeviceInterfaceDetailAX(hDevInfo, &devInterfaceData,
                                          NULL, 0, &requiredSize, NULL);

        PSP_DEVICE_INTERFACE_DETAIL_DATA devDetail =
            (PSP_DEVICE_INTERFACE_DETAIL_DATA)malloc(requiredSize);
        devDetail->cbSize = sizeof(SP_DEVICE_INTERFACE_DETAIL_DATA);

        if (SetupDiGetDeviceInterfaceDetailAX(hDevInfo, &devInterfaceData,
                                              devDetail, requiredSize, NULL, NULL)) {
            HANDLE hTemp = CreateFile(devDetail->DevicePath,
                                      GENERIC_READ | GENERIC_WRITE,
                                      FILE_SHARE_READ | FILE_SHARE_WRITE,
                                      NULL,
                                      OPEN_EXISTING,
                                      0,
                                      NULL);
            if (hTemp != INVALID_HANDLE_VALUE) {
                HIDD_ATTRIBUTES attrib;
                attrib.Size = sizeof(HIDD_ATTRIBUTES);
                if (HidD_GetAttributesX(hTemp, &attrib)) {
                    if (attrib.VendorID == vid && attrib.ProductID == pid) {
                        hDevice = hTemp; // ✅ found!
                        free(devDetail);
                        break;
                    }
                }
                CloseHandle(hTemp);
            }
        }
        free(devDetail);
    }

    SetupDiDestroyDeviceInfoListX(hDevInfo);
    return hDevice;
}

// =====================
// CP2112 Helper Functions
// =====================


int CP2112_GetPartNumber(HANDLE hDevice, BYTE *partNumber)
{
    BYTE buffer[16];
    memset(buffer, 0, sizeof(buffer));

    buffer[0] = CP2112_GET_PART_NUMBER; // Report ID

    if (!HidD_GetFeatureX(hDevice, buffer, sizeof(buffer))) {
        printf("CP2112_GetPartNumber: HidD_GetFeature failed\n");
        return -1;
    }

    *partNumber = buffer[1]; // Part number is at offset 1
    return 0;
}

int CP2112_GetVersion(HANDLE hDevice, WORD *version)
{
    BYTE buffer[16];
    memset(buffer, 0, sizeof(buffer));

    buffer[0] = CP2112_GET_VERSION; // Report ID

    if (!HidD_GetFeatureX(hDevice, buffer, sizeof(buffer))) {
        printf("CP2112_GetVersion: HidD_GetFeature failed\n");
        return -1;
    }

    *version = (buffer[2] << 8) | buffer[1]; // Version bytes
    return 0;
}

void CloseHidDevice(HANDLE hDevice) {
    if (hDevice != INVALID_HANDLE_VALUE && hDevice != NULL) {
        CloseHandle(hDevice);
    }
}


void FreeAdapterFunctions(void)
{
    if (hHidDll) {
        FreeLibrary(hHidDll);
        hHidDll = NULL;
    }
    if (hSetupApiDll) {
        FreeLibrary(hSetupApiDll);
        hSetupApiDll = NULL;
    }
}
