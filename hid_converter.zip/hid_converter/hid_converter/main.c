#include <stdio.h>
#include <stdlib.h>
#include <windows.h>
#include <hidsdi.h>
#include <setupapi.h>
#include "adapter.h"
///for STM32 board , defined in Cube Code Generator`s window
#define VENDOR_ID  1155
#define PRODUCT_ID 22352
#define REPORT_ID 1

#define CP2112_VENDOR_ID 0x10c4
#define CP2112_PRODUCT_ID 0xea90

#define MAX_REPORT_SIZE 64

///---------data markers-------------
#define  data_from_host   18
#define data_to_host  19
//-----------commands----------------
#define write_to_slave  24
#define read_from_slave 25
#define reset_interface 26
#define setup_interface 27
//---error codes-------------------
#define adapter_success 0
#define adapter_AF 1
#define adapter_BERR 2
#define adapter_ARLO 3
#define adapter_OVR 4
#define adapter_timeout 5
#define adapter_other_error 6
#define adapter_busy 7
///payload offset for best CPU performance [report_id|0|0|0|payload_begin_here|....]
#define PAYLOAD_OFFS 4


WORD cp2112Version;
BYTE cp2112PartNumber;


DWORD bytesProcessedG;

///defines for state mashine

typedef struct {
		unsigned char typeOfAction;
		unsigned char* buffPtr; //changes during exec.
		unsigned short numUsbTransations;
		unsigned short numBytesToTransaction;
		unsigned char*  reassembledDataArray; //not changed
		unsigned char slaveAddress;
} statesHandle;

 statesHandle mashineHandle;

unsigned char usbOutBuffer[290]={
		"So she was considering in her own mind (as well as she could, for the "
		"hot day made her feel very sleepy and stupid), whether the pleasure of "
		"making a daisy-chain would be worth the trouble of getting up and "
		"picking the daisies, when suddenly a White Rabbit, Buks Bunny, he eating a carrot"
};

unsigned char usbInBuffer[512];

///function for sending data through I2C
short sendPacketToUsbI2cAdapter(statesHandle * states,
                              HANDLE* pHidHandle,
                              unsigned char slaveAddress,
                              unsigned char* buffer,
                              unsigned short amountOfData) {

    unsigned char reportBuffer[68]={0};  //not used
    unsigned char reportBufferHost[68]={0}; //incoming data for host
    unsigned char reportBufferDev[68]={0};  //outgoing data for device
    DWORD bytesProcessed;
    //1)amount of transactions
    states->numBytesToTransaction = amountOfData;
    states->numUsbTransations = amountOfData / 64;
    if ( (states->numBytesToTransaction % 64) > 0 ) {
         states->numUsbTransations++;
    }
    //2)init pointers and address and operation
    states->slaveAddress = slaveAddress;
    states->typeOfAction = write_to_slave;
    states->buffPtr = buffer;
    states->reassembledDataArray  = buffer;
    //3)Command report:

    reportBufferDev[0] = states->typeOfAction; //operation code
    reportBufferDev[1] = (states->numBytesToTransaction & 0xff); //low byte
    reportBufferDev[2] = (states->numBytesToTransaction >> 8); //high byte
    reportBufferDev[3] = slaveAddress;   //slave address
    //4)Send data to the USB device (it is a blocking operation)
      if (!WriteFile(*pHidHandle, reportBufferDev, 64, &bytesProcessed, NULL)) {
           printf("Write failed with error %lu\n", GetLastError());
           return GetLastError();
      }
    //5)iterate until the last USB transactiion:
    while (states->numUsbTransations > 1) {
        //a)await a signal "data_from_host" from a device:
        if (!ReadFile(*pHidHandle, reportBufferHost, 64, &bytesProcessed, NULL)) {
              printf("ReadFile failed: %lu\n", GetLastError());
              return GetLastError();
           } if (reportBufferHost[0] != data_from_host) {
               printf("protocol error!");
               return -1;
           }

         //b)Sends 64 byte packet to a device:
           //b.1)copying into the report_buffer:
           memcpy(reportBufferDev,states->buffPtr,64);
           //b.3)send the buffer to the USB device:
         if (!WriteFile(*pHidHandle, reportBufferDev, 64, &bytesProcessed, NULL)) {
           printf("Write failed with error %lu\n", GetLastError());
           return GetLastError();
         }
         //c)Increase the pointer:
         states->buffPtr += 64;
         //d)Decrease number of USB packets:
         states->numUsbTransations--;
         //e)..and number bytes for I2C transmission:
         states->numBytesToTransaction -= 64;
    }
    //6)When only one USB transaction left:
    //await for device`s response:
    if (!ReadFile(*pHidHandle, reportBufferHost, 64, &bytesProcessed, NULL)) {
      printf("ReadFile failed: %lu\n", GetLastError());
      return GetLastError();
    } if (reportBufferHost[0] != data_from_host) {
       printf("protocol error!");
       return -1;
    }
    //7)Decrease number of transactions (becomes 0):
    states->numUsbTransations--;
    //8)Send to device the last USB transaction:
      //8.1)copying into the report_buffer:
       memcpy(reportBufferDev,states->buffPtr,states->numBytesToTransaction);
       //8.3)send the buffer to the USB device:
    if (!WriteFile(*pHidHandle, reportBufferDev, 64, &bytesProcessed, NULL)) {
        printf("Write failed with error %lu\n", GetLastError());
        return GetLastError();
    }
    //9)Now the device starts I2C transmission of data, that has been received later
    //So, the host awaits for response with result:
     if (!ReadFile (*pHidHandle, reportBufferHost, 64, &bytesProcessed, NULL)) {
      printf("ReadFile failed: %lu\n", GetLastError());
      return GetLastError();
    }
    //10)return received result:

    return reportBufferHost[0];

}

int main(void)
{

        DWORD bytesWritten = 0;
        DWORD bytesRead = 0;
        HANDLE hSerial =0;

          HANDLE hCom;
    DCB dcbSerialParams = {0};
    COMMTIMEOUTS timeouts = {0};

    char data[] = "Hello STM32\r\n";

    // 1) Open the COM port
    hSerial = CreateFileA(
        "\\\\.\\COM3",
        GENERIC_READ | GENERIC_WRITE,
        0,
        NULL,
        OPEN_EXISTING,
        0,
        NULL
    );

    if (hSerial == INVALID_HANDLE_VALUE) {
        printf("Error opening COM port: %lu\n", GetLastError());
        return 1;
    }

    // 2) Configure serial port
    dcbSerialParams.DCBlength = sizeof(dcbSerialParams);
    //read state of the COM port
    if (!GetCommState(hSerial, &dcbSerialParams)) {
        printf("GetCommState failed: %lu\n", GetLastError());
        return 1;
    }
    //set pararmeters
    dcbSerialParams.BaudRate = CBR_115200; // ignored by CDC
    dcbSerialParams.ByteSize = 8;
    dcbSerialParams.StopBits = ONESTOPBIT;
    dcbSerialParams.Parity   = NOPARITY;

    if (!SetCommState(hSerial, &dcbSerialParams)) {
        printf("SetCommState failed: %lu\n", GetLastError());
        return 1;
    }

    // 3) Configure timeouts
    timeouts.ReadIntervalTimeout         = 2;
    timeouts.ReadTotalTimeoutConstant    = 2;
    timeouts.ReadTotalTimeoutMultiplier  = 1;
    timeouts.WriteTotalTimeoutConstant   = 2;
    timeouts.WriteTotalTimeoutMultiplier = 1;

    if (!SetCommTimeouts(hSerial, &timeouts)) {
        printf("SetCommTimeouts failed: %lu\n", GetLastError());
        return 1;
    }



        // Write 64 bytes
       printf("Device opened successfully!\n");

   printf("Write status: %d /n", sendPacketToUsbI2cAdapter(&mashineHandle, &hSerial,0x20,usbOutBuffer,180));
      printf("Write status: %d /n", sendPacketToUsbI2cAdapter(&mashineHandle, &hSerial,0x20,usbOutBuffer,180));



        ///at the end - close COM port
        CloseHandle(hSerial);

    /// U S B


    /*  OLD HID code
    unsigned char reportBuffer[68]={0};

    DWORD bytesWritten = 0;
    DWORD bytesRead = 0;

    unsigned char inReport[MAX_REPORT_SIZE+1] = {0};
    unsigned char outReport[MAX_REPORT_SIZE+1] = {0};
    strcpy(outReport+1, "It was the White Rabbit, trotting slowly back again, and lookin");


    if (InitAdapterFunctions() != 0) {
        printf("Failed to initialize HID/SetupAPI functions\n");
        return -1;
    }


    HANDLE hDevice = OpenHidDevice( VENDOR_ID,  PRODUCT_ID);
    if (hDevice == INVALID_HANDLE_VALUE) {
        printf("No matching HID device found (VID=0x%04X, PID=0x%04X)\n",
               CP2112_VENDOR_ID, CP2112_PRODUCT_ID);
        FreeAdapterFunctions();
        return -1;
    }

    printf("Device opened successfully!\n");

   printf("Write status: %d /n", sendPacketToUsbI2cAdapter(&mashineHandle, &hDevice,0x20,i2cTxBuffer,32));
      printf("Write status: %d /n", sendPacketToUsbI2cAdapter(&mashineHandle, &hDevice,0x20,i2cTxBuffer+32,64));


    CloseHidDevice(hDevice);


    FreeAdapterFunctions();    */

    return 0;
}
/*

int OldMain(void) {



    HDEVINFO hDevInfo = SetupDiGetClassDevs(&hidGuid, NULL, NULL, DIGCF_PRESENT | DIGCF_DEVICEINTERFACE);
    if (hDevInfo == INVALID_HANDLE_VALUE) {
        printf("Error getting device info\n");
        return 1;
    }

    SP_DEVICE_INTERFACE_DATA devInterfaceData;
    devInterfaceData.cbSize = sizeof(SP_DEVICE_INTERFACE_DATA);

    for (DWORD i = 0; SetupDiEnumDeviceInterfaces(hDevInfo, NULL, &hidGuid, i, &devInterfaceData); i++) {
        DWORD requiredSize = 0;
        SetupDiGetDeviceInterfaceDetail(hDevInfo, &devInterfaceData, NULL, 0, &requiredSize, NULL);
        PSP_DEVICE_INTERFACE_DETAIL_DATA devDetail = (PSP_DEVICE_INTERFACE_DETAIL_DATA)malloc(requiredSize);
        devDetail->cbSize = sizeof(SP_DEVICE_INTERFACE_DETAIL_DATA);

        if (SetupDiGetDeviceInterfaceDetail(hDevInfo, &devInterfaceData, devDetail, requiredSize, NULL, NULL)) {
            HANDLE hDevice = CreateFile(devDetail->DevicePath,
                                        GENERIC_READ | GENERIC_WRITE,
                                        FILE_SHARE_READ | FILE_SHARE_WRITE,
                                        NULL,
                                        OPEN_EXISTING,
                                        FILE_FLAG_OVERLAPPED, // Use 0 for blocking
                                        NULL);
            if (hDevice != INVALID_HANDLE_VALUE) {
                // Optional: check VID/PID
                HIDD_ATTRIBUTES attrib;
                attrib.Size = sizeof(HIDD_ATTRIBUTES);
                HidD_GetAttributes(hDevice, &attrib);
                if (attrib.VendorID == VENDOR_ID && attrib.ProductID == PRODUCT_ID) {
                    printf("Device opened\n");

                    // --- Send report ---
                    unsigned char outReport[MAX_REPORT_SIZE] = {0};
                    outReport[0] = 0x01; // Report ID
                    outReport[1] = 0xAA; // Example data
                    if (!HidD_SetOutputReport(hDevice, outReport, MAX_REPORT_SIZE)) {
                        printf("Write failed\n");
                    }

                    // --- Read report ---
                    unsigned char inReport[MAX_REPORT_SIZE] = {0};
                    if (HidD_GetInputReport(hDevice, inReport, MAX_REPORT_SIZE)) {
                        printf("Read: %02X\n", inReport[1]);
                    }

                    CloseHandle(hDevice);
                }
            }
        }
        free(devDetail);
    }

    SetupDiDestroyDeviceInfoList(hDevInfo);
    return 0;

}
*/
